package com.learning.core.day2session2;

public class LowBalanceException extends Exception {
	public LowBalanceException(String message) {
		super(message);
	}
}