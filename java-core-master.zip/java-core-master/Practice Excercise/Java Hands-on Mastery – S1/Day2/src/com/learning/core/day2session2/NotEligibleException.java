package com.learning.core.day2session2;

class NotEligibleException extends Exception {
    public NotEligibleException(String message) {
        super(message);
    }
}
