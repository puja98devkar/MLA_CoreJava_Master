package com.learning.core.day2session2;

public class NegativeAmountException extends Exception {
	public NegativeAmountException(String message) {
		super(message);
	}
}