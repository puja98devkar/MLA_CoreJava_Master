package com.learning.core.day1session1;

public class Syrup implements MedicineInfo {
	@Override
	public void displayLabel() {
		System.out.println("Syrup is consumable only on perscription.");
	}
	
}

