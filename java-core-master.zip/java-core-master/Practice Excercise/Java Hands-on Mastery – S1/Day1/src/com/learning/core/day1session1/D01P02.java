package com.learning.core.day1session1;

public class D01P02 {
	public static void main(String[] args) {
		MedicineInfo tablet = new Tablet();
		MedicineInfo Syrup = new Syrup();
		MedicineInfo Ointment = new Ointment();
		
		tablet.displayLabel();
		Syrup.displayLabel();
		Ointment.displayLabel();
		
	}

}
