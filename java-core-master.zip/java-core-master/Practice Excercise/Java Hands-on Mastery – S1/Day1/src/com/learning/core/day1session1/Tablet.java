package com.learning.core.day1session1;

public class Tablet implements MedicineInfo {
	@Override
	public void displayLabel() {
		System.out.println("Store Tablets in a cool dry place.");
	}
	
}
