package com.learning.core.day1session1;

public interface MedicineInfo {
	void displayLabel();
}
